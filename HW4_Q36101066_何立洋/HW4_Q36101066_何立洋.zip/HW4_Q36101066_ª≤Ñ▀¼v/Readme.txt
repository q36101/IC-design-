conda install numpy
conda install opencv-python